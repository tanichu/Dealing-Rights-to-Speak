﻿using MvvmCross.Plugins.Messenger;
namespace TradingHatsuwa.Core.Messages
{
    public class CloseMessage : MvxMessage
    {
        public CloseMessage(object sender) : base(sender)
        {
        }
    }
}
