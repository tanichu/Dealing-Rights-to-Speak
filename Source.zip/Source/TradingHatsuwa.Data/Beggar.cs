﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingHatsuwa.Data
{
    public class Beggar
    {
        public int UserId { get; set; }
        public bool Begged { get; set; }
    }
}
