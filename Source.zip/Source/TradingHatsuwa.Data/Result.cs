﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingHatsuwa.Data
{
	public class Result
	{
		public EvaluationItem EvaluationItem { get; set; }
		public double? Score { get; set; }
	}
}
